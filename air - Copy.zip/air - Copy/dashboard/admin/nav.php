<ul id="main-menu" class="">
			
    <li class="active opened active"><a href="index.php"><i class="entypo-gauge"></i><span>Dashboard</span></a></li>
                
	<li><a href="#"><i class="entypo-user-add"></i><span>New Registration</span></a>
          <ul>
			<li class="active">
		
		    <a href="addadmin.php"><span>Add admin</span></a></li>		
			<li><a href="addstd.php"><span>Add Student</span></a></li>
			<li><a href="addfcty.php"><span>Add Faculty</span></a></li>
			
		</ul>
	</li>               
				
	<li><a href="payments.php"><i class="entypo-star"></i><span>Links</span></a></li>

	<li><a href="category.php"><i class="entypo-users"></i><span>Members</span></a>
		<ul>
			<li class="active">
		
		   	
            <li><a href="view_adm.php"><span>View Admin</span></a></li>			
            <li><a href="view_std.php"><span>View Student</span></a></li>	
			<li><a href="view_fty.php"><span>View Faculty</span></a></li>
			
		</ul>
	</li>

	<li><a href="new_health_status.php"><i class="entypo-user-add"></i><span>Courses</span></a> 	

		<li><a href="#"><i class="entypo-quote"></i><span>Classes</span></a>

		<ul>
			<li class="active">
				<a href="new_plan.php"><span>Bisness Deparment</span></a></li>

			<li><a href="change_values.php"><span>Computer Deparment</span></a></li>
		</ul>

	<li><a href="new_plan.php"><i class="entypo-upload-cloud"></i><span>Uploads</span></a>

		<ul>
			<li class="active">
				<a href="over_members_month.php"><span>General Files</span></a>
			</li>

			<li>
				<a href="over_members_year.php"><span>Assignment</span></a>
			</li>

			<li>
				<a href="revenue_month.php"><span>Notic Board</span></a>
			</li>			

		</ul>

	<li><a href="new_plan.php"><i class="entypo-alert"></i><span>Alerts</span></a>

		<ul>
			<li class="active">
				<a href=""><span>New Event</span></a>
			</li>

			<li>
				<a href="sub_end.php"><span>New Query</span></a>
			</li>
			
			<li>
				<a href="sub_end.php"><span>New Message</span></a>
			</li>

		</ul>

	</li>

	<li><a href="more-userprofile.php"><i class="entypo-folder"></i><span>Profile</span></a></li>

	<li><a href="logout.php"><i class="entypo-logout"></i><span>Logout</span></a></li>

</ul>	