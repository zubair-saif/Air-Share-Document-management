﻿<?php
include('db_conn.php');
page_protect();
?>
<!DOCTYPE html>
<html lang="en">
<head> 
    <title><?php  include('favtitle.php'); ?></title>

    <link rel="stylesheet" href="../../neon/js/jquery-ui/css/no-theme/jquery-ui-1.10.3.custom.min.css"  id="style-resource-1">
    <link rel="stylesheet" href="../../neon/css/font-icons/entypo/css/entypo.css"  id="style-resource-2">
    <link rel="stylesheet" href="../../neon/css/font-icons/entypo/css/animation.css"  id="style-resource-3">
    <link rel="stylesheet" href="../../neon/css/neon.css"  id="style-resource-5">
    <link rel="stylesheet" href="../../neon/css/custom.css"  id="style-resource-6">
    <script src="../../neon/js/jquery-1.10.2.min.js"></script>

  
</head>
    <body class="page-body  page-fade">

    	<div class="page-container">	
	
		<div class="sidebar-menu">
	
			<header class="logo-env">
			
			<!-- logo -->
			<div class="logo">
				<a href="index.php">
					<img src="../../img/logo.png" alt="" width="170" height="100" />
				</a>
			</div>
			
					<!-- logo collapse icon -->
					<div class="sidebar-collapse">
				<a href="#" class="sidebar-collapse-icon with-animation"><!-- add class "with-animation" if you want sidebar to have animation during expanding/collapsing transition -->
					<i class="entypo-menu"></i>
				</a>
			</div>
							
			
			<!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
			<div class="sidebar-mobile-menu visible-xs">
				<a href="#" class="with-animation"><!-- add class "with-animation" to support animation -->
					<i class="entypo-menu"></i>
				</a>
			</div>
			
			</header>
    		<?php include('nav.php'); ?>
    	</div>

		
		
    		<div class="main-content">
		
				<div class="row">
					
					<!-- Profile Info and Notifications -->
					<div class="col-md-6 col-sm-8 clearfix">	
							
					</div>
					
					
					<!-- Raw Links -->
					<div class="col-md-6 col-sm-4 clearfix hidden-xs">
						
						<ul class="list-inline links-list pull-right">

							<li>Welcome <?php echo $_SESSION['full_name']; ?> 
							</li>					
						
							<li>
								<a href="logout.php">
									Log Out <i class="entypo-logout right"></i>
								</a>
							</li>
						</ul>
						
					</div>
					
				</div>

			<h2>C Panel</h2>

			<hr>
			<div class="row">
	        <div class="col-sm-3">
	
		     <div class="tile-stats tile-primary">
			<div class="icon"><i class="entypo-list"></i></div>
			<div class="num"  data-start="0" data-end="500" data-duration="1500" data-delay="0"> 
			<?php
							$date  = date('Y-m');
							$query = "select * from subsciption WHERE  paid_date LIKE '$date%'";

							//echo $query;
							$result  = mysqli_query($con, $query);
							$revenue = 0;
							if (mysqli_affected_rows($con) != 0) {
							    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
							        $revenue = $row['paid'] + $revenue;
							    }
							}
							echo $revenue;
							?></div>			
			<h3>Teacher</h3>
		</div>
    	</div>	
		
		<div class="col-sm-3">
	    <div class="tile-stats tile-red">
			<div class="icon"><i class="entypo-user"></i></div>
			<div class="num" data-start="0" data-end="440" data-duration="1500" data-delay="5">
			<?php
							$date  = date('Y-m');
							$query = "select COUNT(*) from user_data WHERE wait='no'";

							//echo $query;
							$result = mysqli_query($con, $query);
							$i      = 1;
							if (mysqli_affected_rows($con) != 0) {
							    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
							        echo $row['COUNT(*)'];
							    }
							}
							$i = 1;
							?>
			</div>
			<h3>Students</h3>	
		</div>
		
	</div>
		<div class="col-sm-3">
		<div class="tile-stats tile-aqua">
			<div class="icon"><i class="entypo-users"></i></div>
			<div class="num" data-start="0" data-end="340" data-duration="1500" data-delay="5">		<?php
							$date  = date('Y-m');
							$query = "select COUNT(*) from user_data WHERE wait='no'";

							//echo $query;
							$result = mysqli_query($con, $query);
							$i      = 1;
							if (mysqli_affected_rows($con) != 0) {
							    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
							        echo $row['COUNT(*)'];
							    }
							}
							$i = 1;
							?></div>			
			<h3>Subscribers</h3>
		</div>
		
	</div>			
      <div class="col-sm-3">	
		<div class="tile-stats tile-blue">
			<div class="icon"><i class="entypo-graduation-cap"></i></div>
			<div class="num" data-start="0" data-end="30" data-duration="1500" data-delay="5">	 <?php
							$date  = date('Y-m');
							$query = "select * from subsciption WHERE  paid_date LIKE '$date%'";

							//echo $query;
							$result  = mysqli_query($con, $query);
							$revenue = 0;
							if (mysqli_affected_rows($con) != 0) {
							    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
							        $revenue = $row['total'] + $revenue;
							    }
							}
							echo $revenue;
							?></div>			
			<h3>Classes</h3>			
		</div>
		</div>
		</div>
		<br />				
<div class="row">
	<div class="col-sm-3">
	
		<div class="tile-stats tile-cyan">
			<div class="icon"><i class="entypo-share"></i></div>
			<div class="num" data-start="0" data-end="450" data-duration="1500" data-delay="5">	 <?php
							$date  = date('Y-m');
							$query = "select * from subsciption WHERE  paid_date LIKE '$date%'";

							//echo $query;
							$result  = mysqli_query($con, $query);
							$revenue = 0;
							if (mysqli_affected_rows($con) != 0) {
							    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
							        $revenue = $row['total'] + $revenue;
							    }
							}
							echo $revenue;
							?></div>
			
			<h3>General Share</h3>
		
		</div>
		</div>			
		<div class="col-sm-3">
	
		<div class="tile-stats tile-pink">
			<div class="icon"><i class="entypo-attention"></i></div>
			<div class="num" data-start="0" data-end="200" data-duration="1500" data-delay="5"> <?php
							$date  = date('Y-m');
							$query = "select * from subsciption WHERE  paid_date LIKE '$date%'";

							//echo $query;
							$result  = mysqli_query($con, $query);
							$revenue = 0;
							if (mysqli_affected_rows($con) != 0) {
							    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
							        $revenue = $row['total'] + $revenue;
							    }
							}
							echo $revenue;
							?></div>
			
			<h3>Notic Borad</h3>
			
		</div>
		
	</div>	
			
			
			<div class="col-sm-3">
	
		<div class="tile-stats tile-plum">
			<div class="icon"><i class="entypo-megaphone"></i></div>
			<div class="num"data-start="0" data-end="4" data-duration="1500" data-delay="5"> <?php
							$date  = date('Y-m');
							$query = "select * from subsciption WHERE  paid_date LIKE '$date%'";

							//echo $query;
							$result  = mysqli_query($con, $query);
							$revenue = 0;
							if (mysqli_affected_rows($con) != 0) {
							    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
							        $revenue = $row['total'] + $revenue;
							    }
							}
							echo $revenue;
							?></div>
			
			<h3>Events</h3>
			
		</div>
     	</div>              
	   <div class="col-sm-3">
		<div class="tile-stats tile-orange">
			<div class="icon"><i class="entypo-tools"></i></div>
			<div class="num" data-start="0" data-end="3" data-duration="1500" data-delay="5">
			<?php
							$date  = date('Y-m');
							$query = "select * from subsciption WHERE  paid_date LIKE '$date%'";

							//echo $query;
							$result  = mysqli_query($con, $query);
							$revenue = 0;
							if (mysqli_affected_rows($con) != 0) {
							    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
							        $revenue = $row['total'] + $revenue;
							    }
							}
							echo $revenue;
							?></div>
			<h3>Setting</h3>
		</div>
		
		</div>
		<!--task start-->
		<script type="text/javascript">
	// Code used to add Todo Tasks
	jQuery(document).ready(function($)
	{
		var $todo_tasks = $("#todo_tasks");
		
		$todo_tasks.find('input[type="text"]').on('keydown', function(ev)
		{
			if(ev.keyCode == 13)
			{
				ev.preventDefault();
				
				if($.trim($(this).val()).length)
				{
					var $todo_entry = $('<li><div class="checkbox checkbox-replace color-white"><input type="checkbox" /><label>'+$(this).val()+'</label></div></li>');
					$(this).val('');
					
					$todo_entry.appendTo($todo_tasks.find('.todo-list'));
					$todo_entry.hide().slideDown('fast');
					replaceCheckboxes();
				}
			}
		});
	});
</script>


	
	<div class="col-sm-3">
		<div class="tile-block" id="todo_tasks">
			
			<div class="tile-header">
				<i class="entypo-list"></i>
				
				<a href="#">
					Tasks
					<span>To do list, tick one.</span>
				</a>
			</div>
			
			<div class="tile-content">
				
				<input type="text" class="form-control" placeholder="Add Task" />
				
				
				<ul class="todo-list">
					<li>
						<div class="checkbox checkbox-replace color-white">
							<input type="checkbox" />
							<label>Meeting</label>
						</div>
					</li>
					
					<li>
						<div class="checkbox checkbox-replace color-white">
							<input type="checkbox" id="task-2" checked />
							<label>Classes </label>
						</div>
					</li>
					
					<li>
						<div class="checkbox checkbox-replace color-white">
							<input type="checkbox" id="task-3" />
							<label>Check Result</label>
						</div>
					</li>
	
				</ul>
				
			</div>
			
			<div class="tile-footer">
				<a href="#">View all tasks</a>
			</div>
			
		</div>
	</div>
		
        </div>	
		<!--end-->
    <script src="../../neon/js/gsap/main-gsap.js" id="script-resource-1"></script>
    <script src="../../neon/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js" id="script-resource-2"></script>
    <script src="../../neon/js/bootstrap.min.js" id="script-resource-3"></script>
    <script src="../../neon/js/joinable.js" id="script-resource-4"></script>
    <script src="../../neon/js/resizeable.js" id="script-resource-5"></script>
    <script src="../../neon/js/neon-api.js" id="script-resource-6"></script>
    <script src="../../neon/js/jquery.validate.min.js" id="script-resource-7"></script>
    <script src="../../neon/js/neon-login.js" id="script-resource-8"></script>
    <script src="../../neon/js/neon-custom.js" id="script-resource-9"></script>
    <script src="../../neon/js/neon-demo.js" id="script-resource-10"></script>
	<footer>
		<?php include('footer.php'); ?>
	</footer>
    </body>
</html>
